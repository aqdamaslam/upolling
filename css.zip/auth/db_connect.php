<?php
//make connection
mysql_connect('localhost', 'root', '');

//select db
mysql_select_db('poll');

?>